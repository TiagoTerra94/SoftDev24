# Instructions

# React Final Project - Tutti Bueno Ristorante - TP_Tiago_Terra

## Backend 

API developed with Node.JS.

### Scripts to run backend

```sh
$ cd backend
$ node app.js
```

## Frontend

Developed with ReactJS

### Scripts to run app

```sh
$ npm run dev
```
