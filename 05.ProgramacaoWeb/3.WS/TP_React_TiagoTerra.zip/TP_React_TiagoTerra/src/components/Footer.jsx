export default function Footer() {
  return (
    <footer className="footer py-3 mt-5">
      <div className="container">
        <div className="footer-bottom">
          <p className="text-sm">
            Developed by Tiago Terra. Course: Software Developer 2024 
          </p>
          <h3>&#128511;</h3>
        </div>
      </div>
    </footer>
  );
}