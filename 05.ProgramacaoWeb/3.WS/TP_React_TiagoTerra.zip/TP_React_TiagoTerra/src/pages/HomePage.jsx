import { useContext } from "react";
import { AuthContext } from "../contexts/AuthContext";
import { Link } from "react-router-dom";

export default function HomePage() {
  const { user } = useContext(AuthContext);

  return (
    <div className="container py-5">
      <div className="row justify-content-center">
        <div className="col-md-10 text-center">
          <h1 className="display-4 mb-4">Welcome to Tutti Bueno Ristorante</h1>
          <img
            src="/src/assets/tuttibueno.png"
            alt="Tutti Bueno Logo"
            className="logo-circular"
          />

          {user ? (
            <div className="row mt-5 fade-in">
              {user.role === "manager" && (
                <>
                  <div className="col-md-6 mb-4">
                    <div className="card h-100 border-primary">
                      <div className="card-body d-flex flex-column p-xl">
                        <h3 className="card-title text-primary">Manage Menus</h3>
                        <p className="card-text flex-grow-1 text-subtext">
                          Create, view, and manage the menus.
                        </p>
                        <Link to="/menus" className="btn btn-primary">View Menus</Link>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-6 mb-4">
                    <div className="card h-100 border-primary">
                      <div className="card-body d-flex flex-column p-xl">
                        <h3 className="card-title text-primary">Create Menu</h3>
                        <p className="card-text flex-grow-1 text-subtext">
                          Add new menus with appetizers, main and desserts.
                        </p>
                        <Link to="/create-menu" className="btn">Create Menu</Link>
                      </div>
                    </div>
                  </div>
                </>
              )}
              
              {user.role === "customer" && (
                <div className="col-md-6 mb-4 mx-auto">
                  <div className="card h-100 border-primary">
                    <div className="card-body d-flex flex-column p-xl">
                      <h3 className="card-title text-primary">Place Order</h3>
                      <p className="card-text flex-grow-1 text-subtext">
                        Choose a menu from our list and place your order.
                      </p>
                      <Link to="/order" className="btn">Place Order</Link>
                    </div>
                  </div>
                </div>
              )}
              
              {user.role === "chef" && (
                <div className="col-md-6 mb-4 mx-auto">
                  <div className="card h-100 border-primary">
                    <div className="card-body d-flex flex-column p-xl">
                      <h3 className="card-title text-primary">Manage Orders</h3>
                      <p className="card-text flex-grow-1 text-subtext">
                        View and update the orders in the kitchen.
                      </p>
                      <Link to="/kitchen" className="btn">View Orders</Link>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="row mt-5">
              <div className="col-md-6 mb-4">
                <div className="card h-100 slide-up">
                  <div className="card-body d-flex flex-column p-xl">
                    <h3 className="card-title text-primary">Login</h3>
                    <p className="card-text flex-grow-1 text-subtext">
                      If you are a customer or chef, please login to access your account.
                    </p>
                    <Link to="/login" className="btn">Login</Link>
                  </div>
                </div>
              </div>
              <div className="col-md-6 mb-4">
                <div className="card h-100 animate-delay-1 slide-up">
                  <div className="card-body d-flex flex-column p-xl">
                    <h3 className="card-title text-primary">Create account</h3>
                    <p className="card-text flex-grow-1 text-subtext">
                      Create an account to explore our menus and place orders.
                    </p>
                    <Link to="/signup" className="btn btn-secondary">Sign Up</Link>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}