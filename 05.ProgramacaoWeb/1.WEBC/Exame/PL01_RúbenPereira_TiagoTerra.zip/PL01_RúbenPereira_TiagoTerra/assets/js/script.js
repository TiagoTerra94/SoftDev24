// Desenvolvido por Rúben Pereira e Tiago Terra

// Carrega as categorias após o load do documento
function loadCategories() {
  document.addEventListener("DOMContentLoaded", () => {
    fetch("https://dummyjson.com/products/categories")
      .then((response) => {
        if (response.ok) {
          return response.json();
        }
      })
      .then((data) => {
        data.forEach((category) => {
          // Adiciona a tag <a>
          const link = document.createElement("a");
          link.href = "#";
          link.textContent = category.name;
          link.dataset.slug = category.slug;

          link.addEventListener("click", (e) => {
            e.preventDefault();
            loadProducts(category);
          });

          categories.appendChild(link);
        });
      });
  });
}

// Carrega os produtos da categoria selecionada
function loadProducts(category) {
  fetch(`https://dummyjson.com/products/category/${category.slug}`)
    .then((response) => {
      if (response.ok) {
        return response.json();
      }
    })
    .then((data) => {
      // Limpa os produtos anteriores
      products.innerHTML = "";

      products.innerHTML = `<h3>Products in category ${category.name}</h3>
      <br>`;

      // Adiciona os produtos da categoria
      let counter = 0;
      data.products.forEach((product) => {
        // Adiciona a tag <div>
        const card = document.createElement("div");
        card.innerHTML = `
        <div>
            <h5>${product.title}</h5>
            <p>Price: $${product.price}</p>
            <p>Rating: ${product.rating}/5 ★</p>
        </div>
    `;
        products.appendChild(card);

        // Adiciona o <hr> se não for o último item dos produtos
        if (counter !== data.products.length - 1) {
          const hr = document.createElement("hr");
          products.appendChild(hr);
        }
        counter++;
      });
    });
}

// Inicializa as funções
loadCategories();
loadProducts();
