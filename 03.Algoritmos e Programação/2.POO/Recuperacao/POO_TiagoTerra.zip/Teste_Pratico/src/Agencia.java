import java.util.ArrayList;

public class Agencia {//
    protected String nome = "Viaje na Maionese";
    ArrayList<Viagem> viagens;

    public Agencia(String nome) {
        this.nome = nome;
        this.viagens = new ArrayList<>();
    }

    public void adicionarViagem(Viagem viagem){
        this.viagens.add(viagem);
    }


    public void editarMaxInscritos(int id , int novoMax){
        for(Viagem viagem: this.viagens) {
            if (id == viagem.getId()) {
                viagem.setMax_inscritos(novoMax);
            } else {
                System.out.println("Viagem inexistente");
            }
        }
    }

    public void maxInscritos(){
        int maxInscritos = 0;
        for(Viagem viagem: this.viagens){
            if(viagem.nInscritos() > maxInscritos){
                viagem.exibirDetalhes();
            }
        }
    }

    public void maiorRendimento(){
        int maiorRendimento = 0;
        for(Viagem viagem: this.viagens){
            if(viagem.rendimentoViagem() > maiorRendimento){
                viagem.exibirDetalhes();
            }
        }
    }

    public void numeroInscritos(int id){
        int numeroInscritos =0;
        for(Viagem viagem: this.viagens){
            if(id == viagem.getId()){
                System.out.println("Numero inscritos na viagem:" + viagem.listaTuristas.size());
                return;
            }
        }
    }

    public void exibirTuristas(int id){
        for(Viagem viagem: this.viagens){
            if(id == viagem.getId()){
                viagem.exibirTurista();
                return;
            }
        }
    }


}
