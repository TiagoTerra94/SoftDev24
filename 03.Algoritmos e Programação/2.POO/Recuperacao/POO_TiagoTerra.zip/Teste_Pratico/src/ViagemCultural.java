import Enums.MetodoDeslocacao;

import java.util.ArrayList;

public class ViagemCultural extends Viagem{
    protected ArrayList<String> monumentos;

    public ViagemCultural(int id, String nome, String destino, int n_dias, MetodoDeslocacao metodoDeslocacao, int max_inscritos, ArrayList<String> monumentos) {
        super(id, nome, destino, n_dias, metodoDeslocacao, max_inscritos);
        this.monumentos = monumentos;
    }
}
