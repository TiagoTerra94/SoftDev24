import Enums.Aventura;
import Enums.MetodoDeslocacao;

public class ViagemAventura extends Viagem{
    protected Aventura tipoAventura;

    public ViagemAventura(int id, String nome, String destino, int n_dias, MetodoDeslocacao metodoDeslocacao, int max_inscritos, Aventura tipoAventura) {
        super(id, nome, destino, n_dias, metodoDeslocacao, max_inscritos);
        this.tipoAventura = tipoAventura;
    }
}
