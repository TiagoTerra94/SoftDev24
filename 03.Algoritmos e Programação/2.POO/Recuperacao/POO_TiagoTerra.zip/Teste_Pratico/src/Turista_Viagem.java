public class Turista_Viagem {
    protected Turista turista;
    protected double precoBilhete;

    public Turista_Viagem(Turista turista, double precoBilhete) {
        this.turista = turista;
        this.precoBilhete = precoBilhete;
    }


    public Turista getTurista() {
        return turista;
    }

    public double getPrecoBilhete() {
        return precoBilhete;
    }

}
