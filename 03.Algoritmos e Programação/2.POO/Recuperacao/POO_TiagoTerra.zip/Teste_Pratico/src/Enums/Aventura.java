package Enums;

public enum Aventura {
    RAFTING, ESCALADA, PAINTBALL, TRILHOS, BTT
}
