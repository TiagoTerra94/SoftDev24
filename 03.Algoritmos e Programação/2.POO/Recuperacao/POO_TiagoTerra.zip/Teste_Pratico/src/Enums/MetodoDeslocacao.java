package Enums;

public enum MetodoDeslocacao {
    AVIAO, AUTOCARRO, COMBOIO,TRANSFER_PRIVADO
}
