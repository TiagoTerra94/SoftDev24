package Enums;

public enum Relaxamento {
    RETIROMONTANHA, PRAIA, SPA
}
