public class Turista {
    protected int id;
    protected String nome;
    protected String email;
    protected String telemovel;
    protected String dataNasc;
    protected String nacionalidade;

    public Turista(int id, String nome, String email, String telemovel, String dataNasc, String nacionalidade) {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.telemovel = telemovel;
        this.dataNasc = dataNasc;
        this.nacionalidade = nacionalidade;
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getEmail() {
        return email;
    }

    public String getTelemovel() {
        return telemovel;
    }

    public String getDataNasc() {
        return dataNasc;
    }

    public String getNacionalidade() {
        return nacionalidade;
    }

    public void dadosTurista(){
        System.out.println(" Id: " + this.id);
        System.out.println(" Nome: " + this.nome);
    }
}
