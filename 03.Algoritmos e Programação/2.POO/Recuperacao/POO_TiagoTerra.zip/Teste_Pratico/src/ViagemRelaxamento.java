import Enums.MetodoDeslocacao;
import Enums.Relaxamento;

public class ViagemRelaxamento extends Viagem{
    protected Relaxamento tipoRelaxamento;

    public ViagemRelaxamento(int id, String nome, String destino, int n_dias, MetodoDeslocacao metodoDeslocacao, int max_inscritos, Relaxamento tipoRelaxamento) {
        super(id, nome, destino, n_dias, metodoDeslocacao, max_inscritos);
        this.tipoRelaxamento = tipoRelaxamento;
    }
}
