import Enums.MetodoDeslocacao;

import java.util.ArrayList;

public class Viagem {
    protected int id;
    protected String nome;
    protected String destino;
    protected int n_dias;
    protected MetodoDeslocacao metodoDeslocacao;
    protected int max_inscritos;
    protected ArrayList<Turista_Viagem> listaTuristas;

    public Viagem(int id, String nome, String destino, int n_dias, MetodoDeslocacao metodoDeslocacao, int max_inscritos) {
        this.id = id;
        this.nome = nome;
        this.destino = destino;
        this.n_dias = n_dias;
        this.metodoDeslocacao = metodoDeslocacao;
        this.max_inscritos = max_inscritos;
        this.listaTuristas = new ArrayList<Turista_Viagem>();
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getDestino() {
        return destino;
    }

    public int getN_dias() {
        return n_dias;
    }

    public MetodoDeslocacao getMetodoDeslocacao() {
        return metodoDeslocacao;
    }

    public int getMax_inscritos() {
        return max_inscritos;
    }

    public void setMax_inscritos(int max_inscritos) {
        this.max_inscritos = max_inscritos;
    }

    public ArrayList<Turista_Viagem> getListaTuristas() {
        return listaTuristas;
    }

    //Metodos de Instancia
    public void inscreverTurista(Turista_Viagem turista){
        if(this.listaTuristas.size() < max_inscritos) {
            this.listaTuristas.add(turista);
        }else{
            System.out.println("Viagem preenchida!");
        }
    }

    public void cancelarReserva(int id){
        for(Turista_Viagem turista: this.listaTuristas){
            if(id == turista.getTurista().getId()){
                this.listaTuristas.remove(turista);
                return;
            }else{
                System.out.println("Turista inexistente");
            }
        }
    }

    public int nInscritos(){
        return this.listaTuristas.size();
    }

    public double rendimentoViagem(){
        double total = 0;
        for(Turista_Viagem turista: this.listaTuristas){
            total += turista.getPrecoBilhete();
        }

        return total;
    }

    public void exibirDetalhes(){
        System.out.println("Nome: " + this.nome + "Destino: " + this.destino + "Dias: " + this.n_dias + "Metodo deslocação: " + this.metodoDeslocacao);
    }

    public void exibirTurista(){
        int counter = 1;
        for(Turista_Viagem turistaViagem: this.listaTuristas) {
            System.out.print("Turista Nº" + counter++);
            turistaViagem.getTurista().dadosTurista();
        }
    }
}

